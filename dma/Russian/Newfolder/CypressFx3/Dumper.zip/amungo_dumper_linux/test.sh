sudo ./AmungoFx3Dumper AmungoItsFx3Firmware.img nt1065.hex dump.bin 0 libusb
