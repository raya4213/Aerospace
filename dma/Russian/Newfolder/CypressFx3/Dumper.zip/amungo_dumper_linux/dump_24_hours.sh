sudo ./AmungoFx3Dumper AmungoItsFx3Firmware.img nt1065.hex dump.bin 86400 libusb
